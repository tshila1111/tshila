var base_url = 'http://localhost:2000/userapp';

function login()
{
    var requestObject = new Object();
    requestObject.action='login';
    requestObject.email=$('#login-email').val();
    requestObject.password=$('#login-password').val();
    
    var payload = {};
    payload.payload =  requestObject;
    
    console.log("payload - " + payload);
    
    $.ajax({
        type: "POST",
        contentType: "application/json",
        url:  base_url+"/loginController/signIn",
        data: JSON.stringify(payload),
        dataType: 'json',
        cache: false,
        timeout: 600000,
        success: function (data) {
            var json = JSON.stringify(data, null, 4);
            $('#login-alert').html(data.payload.statusMessage);
            
            console.log("SUCCESS : ", data);
            //$("#btn-search").prop("disabled", false);
            window.location.href = "dashboard.html"

        },
        error: function (e) {
            $('#login-alert').html(e.responseText);
            console.log("ERROR : ", e);
            //$("#btn-search").prop("disabled", false);
        }
    });
}

function signUp()
{
    var requestObject = new Object();
    requestObject.action='signUp';
    requestObject.email=$('#login-email').val();
    requestObject.password=$('#login-password').val();
    requestObject.firstName=$('#login-firstName').val();
    requestObject.lastName=$('#login-lastName').val();
    
    var payload = {};
    payload.payload =  requestObject;
    
    console.log("payload - " + payload);
    
    $.ajax({
        type: "POST",
        contentType: "application/json",
        url:  base_url+"/userController/signUp",
        data: JSON.stringify(payload),
        dataType: 'json',
        cache: false,
        timeout: 600000,
        success: function (data) {
            var json = JSON.stringify(data, null, 4);
            $('#login-alert').html(data.payload.statusMessage);
            
            console.log("SUCCESS : ", data);
            //$("#btn-search").prop("disabled", false);
            window.location.href = "welcome.html"

        },
        error: function (e) {
            $('#login-alert').html(e.responseText);
            console.log("ERROR : ", e);
            //$("#btn-search").prop("disabled", false);
        }
    });
}