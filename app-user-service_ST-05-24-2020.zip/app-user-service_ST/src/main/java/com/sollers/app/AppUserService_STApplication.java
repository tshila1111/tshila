package com.sollers.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//@EnableAdminServer
@SpringBootApplication
public class AppUserService_STApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppUserService_STApplication.class, args);
	}

}
