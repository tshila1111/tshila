
package com.sollers.app.service.impl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.sollers.app.model.Address;
import com.sollers.app.model.User;
import com.sollers.app.repository.AddressRepository;
import com.sollers.app.repository.UserRepository;
import com.sollers.app.service.IUserService;
import com.sollers.app.vo.AppResponseJson;
import com.sollers.app.vo.RequestJson;

@Service
public class UserServiceImpl implements IUserService {
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private AddressRepository addressRepository;

	@Override
	public User findUserByEmail(String email) {
		return userRepository.findUserByEmail(email);
	}

	@Override
	public AppResponseJson createUserAccount(RequestJson<Map<String, Object>> appRequest) {
		AppResponseJson appResponse = null;
		
		System.out.println("Request from UI - " + appRequest.getPayload().get("firstName") + " <> "
				+ appRequest.getPayload().get("lastName") + " <> " + appRequest.getPayload().get("email"));


		
		User user = new User();

//		//ADDED ADDRESS
//		@SuppressWarnings("unchecked")
//		Map <String, String> addressMap = (Map<String, String>) appRequest.getPayload().get("address");
//		
//		
//		
//		
//		Address userAddress = new Address();
//		//userAddress.setAddressId(Integer.parseInt(addressMap.get("address_id")));
//		userAddress.setStreet(addressMap.get("street"));
//		userAddress.setCity(addressMap.get("city"));
//		userAddress.setState(addressMap.get("state"));
//		userAddress.setCountry(addressMap.get("country"));
//		userAddress.setZipCode(addressMap.get("zipCode"));
//		
//		addressRepository.save(userAddress);
//		
//		user.setAddress(userAddress);
		
		// ADD USER
		user.setEmail((String)appRequest.getPayload().get("email"));
		user.setFirstName((String)appRequest.getPayload().get("firstName"));
		user.setLastName((String)appRequest.getPayload().get("lastName"));
		user.setPassword((String)appRequest.getPayload().get("password"));
		user.setActive(1);
		userRepository.save(user);
		

		
		appResponse = new AppResponseJson();
		appResponse.setStatusCode(0);
		appResponse.setStatusMessage("Success");
		appResponse.setData(user);
		
		return appResponse;
	}

	@Override
	public AppResponseJson deleteByEmail(RequestJson<Map<String, Object>> appRequest) {
		
		AppResponseJson appResponse = null;
		
		

		userRepository.deleteByEmail((String)appRequest.getPayload().get("email"));
				
		appResponse = new AppResponseJson();
		appResponse.setStatusCode(0);
		appResponse.setStatusMessage("Success");
		//appResponse.setData(user);
		
		return appResponse;
	}
	
	@Override
	public AppResponseJson modifyUserAccount(RequestJson<Map<String, Object>> appRequest) {
		AppResponseJson appResponse = null;
		
		System.out.println("Request from UI - " + appRequest.getPayload().get("firstName") + " <> "
				+ appRequest.getPayload().get("lastName") + " <> " + appRequest.getPayload().get("email"));
		
		String email1 = (String)appRequest.getPayload().get("email");
		
		User myUser = userRepository.findUserByEmail(email1);
		
		myUser.setEmail((String)appRequest.getPayload().get("email"));
		myUser.setFirstName((String)appRequest.getPayload().get("firstName"));
		myUser.setLastName((String)appRequest.getPayload().get("lastName"));
		myUser.setPassword((String)appRequest.getPayload().get("password"));
		myUser.setActive(1);
		userRepository.save(myUser);
				
		appResponse = new AppResponseJson();
		appResponse.setStatusCode(0);
		appResponse.setStatusMessage("Updated");
		appResponse.setData(myUser);
		
		return appResponse;
	}
}

