package com.sollers.app.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class ResponseJson implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private AppResponseJson payload;

	public AppResponseJson getPayload() {
		return payload;
	}

	public void setPayload(AppResponseJson payload) {
		this.payload = payload;
	}

}
