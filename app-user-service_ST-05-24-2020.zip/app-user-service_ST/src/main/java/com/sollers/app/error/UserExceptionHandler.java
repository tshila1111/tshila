package com.sollers.app.error;

import java.util.Collections;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.sollers.app.vo.AppResponseJson;
import com.sollers.app.vo.ErrorResponse;
import com.sollers.app.vo.ResponseJson;

public class UserExceptionHandler extends ResponseEntityExceptionHandler {

	private ResponseJson createExceptionBody(UserException userEx, WebRequest webRequest) {
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setTimestamp(new Date());
		errorResponse.setErrorCode(userEx.getErrorCode());
		errorResponse.setErrorMessage(userEx.getErrorMessage());
		// errorResponse.
		ResponseJson finalResponse = new ResponseJson();
		AppResponseJson appResponse = new AppResponseJson();
		appResponse.setStatusCode(1);
		appResponse.setStatusMessage("Failure");
		appResponse.setData(Collections.singletonMap("data", errorResponse));
		finalResponse.setPayload(appResponse);
		return finalResponse;
	}

	@ExceptionHandler(Exception.class)
	public final ResponseEntity<Object> handleAllExceptions(Exception e, WebRequest webRequest) {
		UserException userEx = new UserException("GEN_ERR_001", e);
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(createExceptionBody(userEx, webRequest));
	}

	@ExceptionHandler(UserException.class)
	public final ResponseEntity<Object> handleAllExceptions(UserException userEx, WebRequest webRequest) {
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(createExceptionBody(userEx, webRequest));
	}

}
