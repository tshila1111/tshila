package com.sollers.app.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/*
 * This is our servlet. How do we access this servlet from UI
 * http://localhost:8080/userapp/servletName
 */

//@RestController
@RequestMapping("/sampleController")
//@Controller
@RestController
public class SampleContoller {
	
	@GetMapping("/getMyName")
	public void getMyName(HttpServletRequest request) {
		System.out.println("Call Received...."+request.getParameter("username"));
	}
	
	@PostMapping("/getMyAge")
	public void getMyAge(HttpServletRequest request) {
		System.out.println("Call Received...."+request.getParameter("username"));
	}
	
	@GetMapping("/getUserName/{userName}/{nickName}")
	//@PathVariable - Used for data passes in the URL
	//@RequestParam - Used to extract the data found in query parameters.
	//http://localhost:1000/userapp/userController/getUserName/sunish?nickName=test
	public void getUserName(@PathVariable final String userName, @RequestParam(value="nickName", required=true) String nickName) {
		System.out.println("Call Received 1 - userName --> "+ userName);
		System.out.println("Call Received 1 - nickname --> "+ nickName);
	}
	
	/*
	@PostMapping("/getSecondName")
	public void getMyAge() {
		System.out.println("Call Received...."+request.getParameter("username"));
	}
	*/
}
