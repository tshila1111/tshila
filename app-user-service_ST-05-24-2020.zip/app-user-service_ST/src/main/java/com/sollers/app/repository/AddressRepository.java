

package com.sollers.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.sollers.app.model.Address;

@Component
@Repository
public interface AddressRepository extends JpaRepository<Address, Integer> {

//	User findAddressByEmail(String email);
//	
	List<Address> findAll();
//	
//	void deleteByEmail(String email);
}
