package com.sollers.app.constants;

public class SollersDBConstants {
	public static String JDBC_URL = "db.url";
	public static String JDBC_DBNAME = "db.sid";
	public static String JDBC_USER = "db.user";
	public static String JDBC_PWD = "db.password";
}




//package com.sollers.app.constants;
//
//public class SollersDBConstants {
//	public static String JDBC_URL = "jdbc:mysql://localhost:3306/";
//	public static String JDBC_DBNAME = "sollers-dev";
//	public static String JDBC_USER = "root";
//	public static String JDBC_PASSWORD = "mutshiaudi";
//}
