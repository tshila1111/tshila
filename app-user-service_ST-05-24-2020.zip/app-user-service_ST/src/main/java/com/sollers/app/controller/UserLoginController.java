package com.sollers.app.controller;


import java.util.Map;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sollers.app.model.User;
import com.sollers.app.repository.UserRepository;
import com.sollers.app.service.IUserService;
import com.sollers.app.vo.AppResponseJson;
import com.sollers.app.vo.RequestJson;
import com.sollers.app.vo.ResponseJson;
//import com.sollers.app.repository.UserRepository;


@CrossOrigin(origins="*",allowedHeaders="*")
@RequestMapping("/loginController")
@RestController
public class UserLoginController {
	
	@Autowired
	private IUserService userService;
	
	
	@Autowired
	private UserRepository userRepository;
		

	// REsponse - Use ResponseEntity
	@PostMapping("/signIn")
	public ResponseEntity<ResponseJson>  signIn(@RequestBody final RequestJson<Map<String, Object>> appRequest) {
		
		ResponseJson finalResponse = null;
		AppResponseJson appResponse = null;

		finalResponse = new ResponseJson();
		appResponse = new AppResponseJson();
 


		String email1 = (String) appRequest.getPayload().get("email");
		String password1 = (String) appRequest.getPayload().get("password");
		
		// Read Json
		System.out.println("email - " + email1);
		System.out.println("password - " + password1);

		// Check if user already exists
		User userExists = userService.findUserByEmail(email1);

		if (userExists != null) {
			
			String dataBasePassword = userExists.getPassword();
			
			if (dataBasePassword.equalsIgnoreCase(password1)) {
				System.out.println("Welcome!" + userExists);
				appResponse.setStatusCode(0);
				appResponse.setStatusMessage("Success");
				appResponse.setData(userExists);
				userExists.setActive(1);
			}

			else {
				System.out.println("Wrong password entered!");
				appResponse.setStatusCode(0);
				appResponse.setStatusMessage("Wrong Password");
			
			}
		} else {
			System.out.println("This user does not exist");
			appResponse.setStatusCode(0);
			appResponse.setStatusMessage("User not found");
			//appResponse.setData(userExists);
		}

		
		//return
		finalResponse.setPayload(appResponse);
		return new ResponseEntity<>(finalResponse, HttpStatus.OK);

	}


	public IUserService getUserService() {
		return userService;
	}


	public void setUserService(IUserService userService) {
		this.userService = userService;
	}


	public UserRepository getUserRepostory() {
		return userRepository;
	}


	public void setUserRepostory(UserRepository userRepostory) {
		this.userRepository = userRepostory;
	}

	
}//END CLASS













//
//package com.sollers.app.controller;
//
//import java.util.HashMap;
//import java.util.Map;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.sollers.app.model.User;
//import com.sollers.app.service.IUserService;
//import com.sollers.app.vo.AppResponseJson;
//import com.sollers.app.vo.RequestJson;
//import com.sollers.app.vo.ResponseJson;
//
//@RequestMapping("/loginController")
//@RestController
//public class UserLoginController {
//
//	@Autowired
//	private IUserService userService;
//	
//	
//	@GetMapping("/login")
//	public ResponseEntity<ResponseJson> userLogin(@RequestBody final RequestJson<Map<String, Object>> appRequest) {
//
//		ResponseJson finalResponse = new ResponseJson();
//		AppResponseJson appResponse = new AppResponseJson();
//		
//		String email1 = (String) appRequest.getPayload().get("email");
//		String password1 = (String) appRequest.getPayload().get("password");
//		
//		Map<String, Object> m = new HashMap<>();
//		
//		
//		
//		User myUser = userService.findUserByEmail(email1);
//		
//		m.put("Entered User", myUser);
//
//		if (myUser != null) {
//			
//			String dataBasePassword = myUser.getPassword();
//			
////			if(dataBasePassword.equals(password1)) {
//				
//				System.out.println("Welcome");
//				appResponse.setStatusCode(0);
//				appResponse.setStatusMessage("Welcome User");
//				appResponse.setData(myUser);
//				
////			}
////			else {
////			System.out.println("Wrong password provided");
////			
////			}
////		} else {
////			System.out.println("User does not exist in database ");
////			appResponse.setStatusCode(0);
////			appResponse.setStatusMessage("UserNotFound");
////			appResponse.setData(myUser);
//		}
//		
//
//		finalResponse.setPayload(appResponse);
//		return new ResponseEntity<>(finalResponse, HttpStatus.OK);
//	
//		}//end main
//}//end class
//
////String email = JOptionPane.showInputDialog("Enter your email");
////
////User myUser = userService.findUserByEmail(email);
////
////JOptionPane.showMessageDialog(null, "Welcome " + myUser.getFirstName());