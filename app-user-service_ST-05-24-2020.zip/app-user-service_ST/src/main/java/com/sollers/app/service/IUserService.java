
package com.sollers.app.service;

import java.util.*;

import com.sollers.app.model.User;
import com.sollers.app.vo.AppResponseJson;
import com.sollers.app.vo.RequestJson;

public interface IUserService {

	public User findUserByEmail(String email);
	
	public AppResponseJson createUserAccount(RequestJson<Map<String, Object>> appRequest);
	
	public AppResponseJson modifyUserAccount(RequestJson<Map<String, Object>> appRequest);
	
	public AppResponseJson deleteByEmail(RequestJson<Map<String, Object>> appRequest);
}
