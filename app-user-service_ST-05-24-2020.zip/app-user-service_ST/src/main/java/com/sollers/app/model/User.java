
package com.sollers.app.model;

import java.util.List;

import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name = "userspringboot")
public class User {
	public User() {
	
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "user_id")
	private int uid;

	@Column(name = "email")
	private String email;

	@Column(name = "password")
	private String password;

	@Column(name = "first_Name")
	private String firstName;

	@Column(name = "last_Name")
	private String lastName;

	@Column(name = "active")
	private int active;

//	@OneToMany(targetEntity = Address.class, cascade=CascadeType.ALL)
//	@JoinColumn(name= "my_User_id", referencedColumnName ="user_id")	
	
	@OneToOne(cascade=CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "user")
	private Address address;


	//CONSTRUCTOR WITH FIELDS
	public User(int uid, String firstName,Address address, String lastName,  String email,
			 String password, int active) {
		super();
		this.uid = uid;
		this.firstName = firstName;
		this.lastName = lastName;
		this.active = active;
		this.email = email;
		this.address = address;
		this.password=password;
	}

	//GETTER SETTERS
	
	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getUid() {
		return uid;
	}

	public void setUid(int uid) {
		this.uid = uid;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getActive() {
		return active;
	}

	public void setActive(int active) {
		this.active = active;
	}


	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
		
		
	}
	


	@Override
	public String toString() {
		return "User [uid=" + uid + ", firstName=" + firstName + ", lastName=" + lastName +  ", email=" + email + ", password=" + password + ", is active = " + active + "]";
	}
}