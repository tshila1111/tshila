
package com.sollers.app.model;

import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
//import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name = "address")
public class Address {
	public Address() {
	
	}

	@Id
	@Column(name = "address_id")
	private int address_id;
	
	@Column(name = "street")
	private String street;

	@Column(name = "city")
	private String city;
	
	@Column(name = "state")
	private String state;
	
	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	@Column(name = "country")
	private String country;

	@Column(name = "zip_code")
	private String zipCode;
	 
	 @OneToOne(fetch = FetchType.LAZY, optional = false)
	 @JoinColumn(name = "my_user_id", nullable = false)
	 private User user;

	
	
	//GETTERS SETTERS
	public int getId() {
		return address_id;
	}


	public void setAddressId(int id) {
		this.address_id = id;
	}


	public String getStreet() {
		return street;
	}


	public void setStreet(String street) {
		this.street = street;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	public String getZipCode() {
		return zipCode;
	}


	public void setZipCode(String zip_code) {
		this.zipCode = zip_code;
	}


	public User getUser() {
		return user;
	}


	public void setUser(User user) {
		this.user = user;
	}




	@Override
	public String toString() {
		return "Address id=" + address_id + ", street=" + street + ", city=" + city +  ", country=" + country + ", zip_code=" + zipCode + "]";
	}
}