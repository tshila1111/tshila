package com.sollers.app.controller;


import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sollers.app.model.User;
//import com.sollers.app.repository.AddressRepository;
import com.sollers.app.repository.UserRepository;
import com.sollers.app.service.IUserService;
import com.sollers.app.vo.AppResponseJson;
import com.sollers.app.vo.RequestJson;
import com.sollers.app.vo.ResponseJson;
//import com.sollers.app.repository.UserRepository;

@CrossOrigin(origins="*",allowedHeaders="*")
@RequestMapping("/userController")
@RestController
public class UserController {
	
	@Autowired
	private IUserService userService;
	
	
	@Autowired
	private UserRepository userRepository;
	
//	@Autowired
//	private AddressRepository addressRepository;
		

	// REsponse - Use ResponseEntity
	@PostMapping("/signUp")
	public ResponseEntity<ResponseJson>  signUp(@RequestBody final RequestJson<Map<String, Object>> appRequest) {
		
		ResponseJson finalResponse = new ResponseJson();
		AppResponseJson appResponse = new AppResponseJson();
 
		// Read Json
		System.out.println("request - " + appRequest.getPayload().get("action"));
		System.out.println("request - " + appRequest.getPayload().get("firstname"));

		String email = (String) appRequest.getPayload().get("email");

		// Check if user already exists
		User userExists = userService.findUserByEmail(email);

		if (userExists != null) {
			System.out.println("There is already a user registered with the email provided");
			appResponse.setStatusCode(0);
			appResponse.setStatusMessage("User Already Exists");
			appResponse.setData(userExists);
		} else {
			System.out.println("Creating a new user: ");
			appResponse = userService.createUserAccount(appRequest);
		}

		finalResponse.setPayload(appResponse);
		return new ResponseEntity<>(finalResponse, HttpStatus.OK);

	}

	// REsponse - Use ResponseEntity
		@PostMapping("/modifyUser")
		public ResponseEntity<ResponseJson>  modifyUser(@RequestBody final RequestJson<Map<String, Object>> appRequest) {
			
			ResponseJson finalResponse = new ResponseJson();
			AppResponseJson appResponse = new AppResponseJson();
			
			
			//appResponse = userService.modifyUserAccount(appRequest);
			
			String email = (String) appRequest.getPayload().get("email");

			// Check if user already exists
			User userExists = userService.findUserByEmail(email);

			if (userExists != null) {
				System.out.println("Updating User");
			
				appResponse = userService.modifyUserAccount(appRequest);
				
			} else {
				System.out.println("This User does not exist");
				appResponse.setStatusCode(0);
				appResponse.setStatusMessage("User not found");
			}
	
			finalResponse.setPayload(appResponse);
			return new ResponseEntity<>(finalResponse, HttpStatus.OK);

		}//end modify
	
		@PostMapping("/getAllUsers")
		public ResponseEntity<ResponseJson>  getAllUsers() {
			
			ResponseJson finalResponse = null;
			AppResponseJson appResponse = null;

			finalResponse = new ResponseJson();
			appResponse = new AppResponseJson();
	

			// Check if user already exists
			List<User> myList = userRepository.findAll();

			if (myList != null) {
				System.out.println("Users returned");
				appResponse.setStatusCode(0);
				appResponse.setStatusMessage("Success");
				appResponse.setData(myList);
			} else {
				System.out.println("No Users in Database ");
			
			}

			finalResponse.setPayload(appResponse);
			return new ResponseEntity<>(finalResponse, HttpStatus.OK);

		}
		
		@PostMapping("/deleteUser")
		public ResponseEntity<ResponseJson>  deleteUser(@RequestBody final RequestJson<Map<String, Object>> appRequest) {


			ResponseJson finalResponse = new ResponseJson();
			AppResponseJson appResponse = new AppResponseJson();
	
			String email = (String) appRequest.getPayload().get("email");

			// Check if user already exists
			User userExists = userService.findUserByEmail(email);

			if (userExists != null) {
				
				appResponse = userService.deleteByEmail(appRequest);
				
				System.out.println("The User has been deleted");
				
				//appResponse.setData(userExists);
				
				
			} else {
				System.out.println("This user already does not exist ");
				
				appResponse.setStatusCode(0);
				appResponse.setStatusMessage("User Not Found");
			}
			
			// Check if user already exists
			List<User> myList = userRepository.findAll();

			if (myList != null) {
				System.out.println("User Deleted");
				appResponse.setStatusCode(0);
				appResponse.setStatusMessage("Success");
				appResponse.setData(myList);
			} else {
				System.out.println("No Users in Database ");
			
			}

			finalResponse.setPayload(appResponse);
			return new ResponseEntity<>(finalResponse, HttpStatus.OK);

		}
	public IUserService getUserService() {
		return userService;
	}


	public void setUserService(IUserService userService) {
		this.userService = userService;
	}


	public UserRepository getUserRepostory() {
		return userRepository;
	}


	public void setUserRepostory(UserRepository userRepostory) {
		this.userRepository = userRepostory;
	}

	
}//END CLASS
